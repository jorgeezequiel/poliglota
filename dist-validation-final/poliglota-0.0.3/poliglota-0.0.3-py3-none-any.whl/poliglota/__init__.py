"""Poliglota locale synchronization and validation utilities."""

from __future__ import annotations

__all__ = ["__version__"]
__version__ = "0.0.3"
