from __future__ import annotations

import logging
import tomllib
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from poliglota import cli as cli_module

if TYPE_CHECKING:
    from collections.abc import Callable


@pytest.fixture
def mock_hf_cache_path(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    cache_root = tmp_path / "hf-cache"
    (cache_root / "hub").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HF_HOME", str(cache_root))
    return cache_root


@pytest.fixture
def mock_environ(monkeypatch: pytest.MonkeyPatch) -> Callable[[str | None], None]:
    def _set(value: str | None) -> None:
        if value is None:
            monkeypatch.delenv("HF_HUB_OFFLINE", raising=False)
            return
        monkeypatch.setenv("HF_HUB_OFFLINE", str(value))

    return _set


@pytest.mark.unit
def test_ml_dependencies_are_optional_extras() -> None:
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    dependencies = data["project"]["dependencies"]
    assert any(item.startswith("rich") for item in dependencies)
    assert not any(
        item.startswith(("torch", "transformers", "huggingface-hub", "sacremoses"))
        for item in dependencies
    )
    extras = data["project"]["optional-dependencies"]
    assert any(item.startswith("torch") for item in extras["translation"])
    assert extras["translation"] == extras["gpu"]


@pytest.mark.parametrize(
    ("encoding", "expected"),
    [("utf-8", True), ("cp1252", False), ("windows-1252", False), ("ascii", True), (None, True)],
)
def test_terminal_supports_unicode_for_known_and_unknown_encodings(
    monkeypatch: pytest.MonkeyPatch, encoding: str | None, expected: bool
) -> None:
    class Stream:
        pass

    stream = Stream()
    stream.encoding = encoding
    monkeypatch.setattr(cli_module.sys, "stdout", stream)
    assert cli_module._terminal_supports_unicode() is expected


@pytest.mark.unit
def test_select_default_motor_supported_direction() -> None:
    assert cli_module._select_default_motor("en_US", "pt_BR") == "Helsinki-NLP/opus-mt-tc-big-en-pt"


@pytest.mark.unit
def test_select_default_motor_pt_to_ja_prefers_nllb() -> None:
    assert cli_module._select_default_motor("pt_BR", "ja_JP") == "facebook/nllb-200-distilled-600M"


@pytest.mark.unit
def test_select_default_motor_rejects_reverse_direction() -> None:
    with pytest.raises(ValueError, match="Unsupported default motor pair"):
        cli_module._select_default_motor("pt_BR", "en_US")


@pytest.mark.unit
def test_select_default_motor_mbart_fallback(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("1")
    cache_dir = mock_hf_cache_path / "hub" / "Helsinki-NLP--opus-mt-en-fr"
    cache_dir.mkdir(parents=True, exist_ok=True)

    assert cli_module._select_default_motor("en", "fr") == "Helsinki-NLP/opus-mt-en-fr"


@pytest.mark.unit
def test_select_default_motor_unsupported_pair() -> None:
    with pytest.raises(ValueError, match="Unsupported default motor pair"):
        cli_module._select_default_motor("xx", "yy")


@pytest.mark.unit
def test_select_default_motor_env_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("POLIGLOTA_DEFAULT_MOTOR", "Helsinki-NLP/opus-mt-en-es")

    assert cli_module._select_default_motor("pt_BR", "en_US") == "Helsinki-NLP/opus-mt-en-es"


@pytest.mark.unit
def test_normalize_locale_code_handles_dashes_and_case() -> None:
    assert cli_module._normalize_locale_code("pt-BR") == "pt_BR"
    assert cli_module._normalize_locale_code("en-us") == "en_US"
    assert cli_module._locale_to_engine_code("pt-BR") == "pt"


@pytest.mark.unit
def test_select_default_motor_offline_mode_skips_missing_m2m_cache(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("1")
    (mock_hf_cache_path / "hub" / "Helsinki-NLP--opus-mt-en-fr").mkdir(parents=True, exist_ok=True)

    assert cli_module._select_default_motor("en", "fr") == "Helsinki-NLP/opus-mt-en-fr"


@pytest.mark.unit
def test_verify_offline_with_cache_present(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("1")
    cache_dir = mock_hf_cache_path / "hub" / "facebook--m2m100_418M"
    cache_dir.mkdir(parents=True, exist_ok=True)

    assert cli_module._verify_offline_capability("facebook/m2m100_418M") is True


@pytest.mark.unit
def test_verify_offline_with_real_hf_layout_cache_present(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("1")
    cache_dir = mock_hf_cache_path / "hub" / "models--facebook--m2m100_418M"
    cache_dir.mkdir(parents=True, exist_ok=True)

    assert cli_module._verify_offline_capability("facebook/m2m100_418M") is True


@pytest.mark.unit
def test_check_model_cached_real_hf_hub_layout(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    cache_root = tmp_path / "hf-cache"
    hub_root = cache_root / "hub"
    snapshot = hub_root / "models--facebook--nllb-200-distilled-600M" / "snapshots" / "abc123"
    snapshot.mkdir(parents=True, exist_ok=True)
    (snapshot / "config.json").write_text('{"model_type": "nllb"}', encoding="utf-8")
    (snapshot / "pytorch_model.bin").write_bytes(b"\0" * 128)
    (snapshot / "tokenizer_config.json").write_text(
        '{"tokenizer_class": "NLLBTokenizer"}', encoding="utf-8"
    )
    monkeypatch.setenv("HF_HOME", str(cache_root))

    assert cli_module.gpu.check_model_cached("facebook/nllb-200-distilled-600M") is True


@pytest.mark.unit
def test_verify_offline_with_cache_missing(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("1")

    with pytest.raises(RuntimeError, match="Model cache not available for offline mode"):
        cli_module._verify_offline_capability("facebook/m2m100_418M")


@pytest.mark.unit
def test_verify_offline_mode_disabled(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("0")

    assert cli_module._verify_offline_capability("facebook/m2m100_418M") is False


@pytest.mark.unit
def test_verify_offline_with_cache_present_when_offline_disabled(
    mock_environ: Callable[[str | None], None],
    mock_hf_cache_path: Path,
) -> None:
    mock_environ("0")
    (mock_hf_cache_path / "hub" / "facebook--m2m100_418M").mkdir(parents=True, exist_ok=True)

    assert cli_module._verify_offline_capability("facebook/m2m100_418M") is True


@pytest.mark.unit
def test_validate_m2m_no_warning(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.WARNING, logger="poliglota.cli"):
        cli_module._validate_resource_footprint("M2M-100-418M")

    assert not any("requires" in record.message.lower() for record in caplog.records)


@pytest.mark.unit
def test_validate_mbart_ram_warning(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.WARNING, logger="poliglota.cli"):
        cli_module._validate_resource_footprint("mBART-50")

    assert any("2GB+ may cause OOM" in record.message for record in caplog.records)


@pytest.mark.unit
def test_validate_nllb_both_warnings(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.WARNING, logger="poliglota.cli"):
        cli_module._validate_resource_footprint("NLLB-200")

    messages = [record.message for record in caplog.records]
    assert any("2GB+ may impact install" in message for message in messages)
    assert any("2GB+ may cause OOM" in message for message in messages)


@pytest.mark.unit
def test_validate_unknown_model_graceful(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.INFO, logger="poliglota.cli"):
        cli_module._validate_resource_footprint("unknown-model")

    assert any(
        "No Phase D resource footprint benchmark available" in record.message
        for record in caplog.records
    )
